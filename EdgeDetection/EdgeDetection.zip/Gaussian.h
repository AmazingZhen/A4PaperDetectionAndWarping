#ifndef _GAUSSIAN_H_
#define _GAUSSIAN_H_

#include "CImg.h"
#include "stdafx.h"
#include <cmath>
#include <cassert>

using namespace cimg_library;

float getGaussianDistribution(int x, int y, float sigma);

CImg<float> getGaussianMask(int windowSize);
CImg<float> getOneDimensionalGaussianMask(int windowSize, bool isX);
CImg<float> getOneDimensionalDerivativeOfGaussianMask(int windowSize, bool isX);


#endif