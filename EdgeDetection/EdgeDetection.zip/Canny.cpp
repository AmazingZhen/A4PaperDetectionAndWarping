#include "stdafx.h"
#include "Canny.h"
#include <iostream>

using namespace std;

CImg<float> getOneDimensionalGradient(const CImg<float>& src_img, bool isX) {
	return src_img.get_correlate(getOneDimensionalDerivativeOfGaussianMask(WINDOW_SIZE, isX));
}

CImg<float> getGradient(const CImg<float>& dx, const CImg<float>& dy) {
	assert(dx.width() == dy.width() && dx.height() == dy.height());

	int dst_width = dx.width();
	int dst_height = dx.height();

	CImg<float> gradient(dst_width, dst_height, 1, 1, 0);

	for (int col = 0; col < dst_width; col++) {
		for (int row = 0; row < dst_height; row++) {
			float res = sqrt(dx(col, row) * dx(col, row) + dy(col, row) * dy(col, row));
			gradient(col, row) = res;
		}
	}

	return gradient;
}

CImg<unsigned char> getAngelOfGradient(const CImg<float>& dx, const CImg<float>& dy) {
	assert(dx.width() == dy.width() && dx.height() == dy.height());

	int dst_width = dx.width();
	int dst_height = dx.height();

	CImg<float> theta(dst_width, dst_height, 1, 1, 0);
	for (int col = 0; col < dst_width; col++) {
		for (int row = 0; row < dst_height; row++) {
			if (dx(col, row) == 0) {
				// tan(theta) = 0
				if (dy(col, row) == 0) {
					theta(col, row) = 0;
				}
				// tan(theta) = infinity
				else {
					theta(col, row) = 90;
				}
			}
			else {
				float tan_theta = dy(col, row) / dx(col, row);

				if (tan_theta > -0.4142 && tan_theta <= 0.4142) {
					theta(col, row) = 0;
				}
				else if (tan_theta > 0.4142 && tan_theta < 2.4142) {
					theta(col, row) = 45;
				}
				else if (abs(tan_theta) >= 2.4142) {
					theta(col, row) = 90;
				}
				else if (tan_theta > -2.4142 && tan_theta <= -0.4142) {
					theta(col, row) = 135;
				}
			}
		}
	}

	return theta;
}

CImg<float> nonMaximumSuppression(const CImg<float>& gradient, const CImg<unsigned char>& theta) {
	assert(gradient.width() == theta.width() && gradient.height() == theta.height());

	int dst_width = gradient.width();
	int dst_height = gradient.height();

	CImg<float> res(dst_width, dst_height, 1, 1, 0);
	for (int col = 1; col < dst_width - 1; col++) {
		for (int row = 1; row < dst_height - 1; row++) {
			if (theta(col, row) == 0) {
				if (gradient(col, row) > gradient(col - 1, row) && gradient(col, row) > gradient(col + 1, row)) {
					res(col, row) = gradient(col, row);
				}
				else {
					res(col, row) = 0;
				}
			}
			else if (theta(col, row) == 45) {
				if (gradient(col, row) > gradient(col - 1, row - 1) && gradient(col, row) > gradient(col + 1, row + 1)) {
					res(col, row) = gradient(col, row);
				}
				else {
					res(col, row) = 0;
				}
			}
			else if (theta(col, row) == 90) {
				if (gradient(col, row) > gradient(col, row - 1) && gradient(col, row) > gradient(col, row + 1)) {
					res(col, row) = gradient(col, row);
				}
				else {
					res(col, row) = 0;
				}
			}
			else if (theta(col, row) == 135) {
				if (gradient(col, row) > gradient(col - 1, row + 1) && gradient(col, row) > gradient(col + 1, row - 1)) {
					res(col, row) = gradient(col, row);
				}
				else {
					res(col, row) = 0;
				}
			}
		}
	}

	return res;
}

void findPixelConnectToEdge(int col, int row, const CImg<float>& suppression, CImg<float>& res, float threshold_low, float threshold_high) {
	if (col < 0 || col >= suppression.width())
		return;
	if (row < 0 || row >= suppression.height())
		return;

	assert(suppression.width() == res.width() && suppression.height() == res.height());

	if (res(col, row) == 0 && suppression(col, row) >= threshold_low && suppression(col, row) < threshold_high) {
		res(col, row) = 255;
		// 8-adjacency
		findPixelConnectToEdge(col - 1, row - 1, suppression, res, threshold_low, threshold_high);
		findPixelConnectToEdge(col, row - 1, suppression, res, threshold_low, threshold_high);
		findPixelConnectToEdge(col + 1, row - 1, suppression, res, threshold_low, threshold_high);
		findPixelConnectToEdge(col - 1, row, suppression, res, threshold_low, threshold_high);
		findPixelConnectToEdge(col + 1, row, suppression, res, threshold_low, threshold_high);
		findPixelConnectToEdge(col - 1, row + 1, suppression, res, threshold_low, threshold_high);
		findPixelConnectToEdge(col, row + 1, suppression, res, threshold_low, threshold_high);
		findPixelConnectToEdge(col + 1, row + 1, suppression, res, threshold_low, threshold_high);
	}
}


CImg<unsigned char> hysteresisThresholding(const CImg<float>& suppression, int threshold_low, int threshold_high) {
	int dst_width = suppression.width();
	int dst_height = suppression.height();

	CImg<float> res(dst_width, dst_height, 1, 1, 0);

	int max = 0;
	for (int col = 2; col < dst_width - 2; col++) {
		for (int row = 2; row < dst_height - 2; row++) {
			if (suppression(col, row) > max) {
				max = suppression(col, row);
			}
		}
	}

	for (int col = 2; col < dst_width - 2; col++) {
		for (int row = 2; row < dst_height - 2; row++) {
			if (suppression(col, row) >= threshold_high) {
				res(col, row) = 255;
			}
			else if (suppression(col, row) < threshold_low) {
				res(col, row) = 0;
			}
		}
	}

	// 8-adjacency
	for (int col = 2; col < dst_width - 2; col++) {
		for (int row = 2; row < dst_height - 2; row++) {
			if (res(col, row) != 0) {
				findPixelConnectToEdge(col - 1, row - 1, suppression, res, threshold_low, threshold_high);
				findPixelConnectToEdge(col, row - 1, suppression, res, threshold_low, threshold_high);
				findPixelConnectToEdge(col + 1, row - 1, suppression, res, threshold_low, threshold_high);
				findPixelConnectToEdge(col - 1, row, suppression, res, threshold_low, threshold_high);
				findPixelConnectToEdge(col + 1, row, suppression, res, threshold_low, threshold_high);
				findPixelConnectToEdge(col - 1, row + 1, suppression, res, threshold_low, threshold_high);
				findPixelConnectToEdge(col, row + 1, suppression, res, threshold_low, threshold_high);
				findPixelConnectToEdge(col + 1, row + 1, suppression, res, threshold_low, threshold_high);
			}
		}
	}
	return res;
}

CImg<unsigned char> cannyEdgeDection(const CImg<float>& src_img) {
	CImg<float> dx = getOneDimensionalGradient(src_img, true);
	CImg<float> dy = getOneDimensionalGradient(src_img, false);

	CImg<float> gradient = getGradient(dx, dy);
	CImg<unsigned char> theta = getAngelOfGradient(dx, dy);

	CImg<float> sup_res = nonMaximumSuppression(gradient, theta);
	CImg<unsigned char> res = hysteresisThresholding(sup_res, HYSTERESIS_THRESHOLD_LOW, HYSTERESIS_THRESHOLD_HIGH);

	return res;
}
//
//int getNumOfEdgePixelConnectToEdge(int col, int row, const CImg<unsigned char>& canny_edge, CImg<bool>& has_visited) {
//	if (col < 0 || col >= canny_edge.width())
//		return 0;
//	if (row < 0 || row >= canny_edge.height())
//		return 0;
//
//	assert(canny_edge.width() == has_visited.width() && canny_edge.height() == has_visited.height());
//
//	int connectivity_count = 0;
//
//	if (canny_edge(col, row) != 0 && has_visited(col, row) == false) {
//		has_visited(col, row) = true;
//		connectivity_count += 1;
//		// 8-adjacency
//		connectivity_count += getNumOfEdgePixelConnectToEdge(col - 1, row - 1, canny_edge, has_visited);
//		connectivity_count += getNumOfEdgePixelConnectToEdge(col, row - 1, canny_edge, has_visited);
//		connectivity_count += getNumOfEdgePixelConnectToEdge(col + 1, row - 1, canny_edge, has_visited);
//		connectivity_count += getNumOfEdgePixelConnectToEdge(col - 1, row, canny_edge, has_visited);
//		connectivity_count += getNumOfEdgePixelConnectToEdge(col + 1, row, canny_edge, has_visited);
//		connectivity_count += getNumOfEdgePixelConnectToEdge(col - 1, row + 1, canny_edge, has_visited);
//		connectivity_count += getNumOfEdgePixelConnectToEdge(col, row + 1, canny_edge, has_visited);
//		connectivity_count += getNumOfEdgePixelConnectToEdge(col + 1, row + 1, canny_edge, has_visited);
//	}
//
//	return connectivity_count;
//}
//
//void drawPixelConnectToEdge(int col, int row, const CImg<unsigned char>& canny_edge, CImg<unsigned char>& target_edge, CImg<bool>& has_drawed) {
//	if (col < 0 || col >= canny_edge.width())
//		return;
//	if (row < 0 || row >= canny_edge.height())
//		return;
//
//	assert(canny_edge.width() == target_edge.width() && canny_edge.height() == target_edge.height());
//
//	if (canny_edge(col, row) != 0 && has_drawed(col, row) == false) {
//		target_edge(col, row) = 255;
//		has_drawed(col, row) = true;
//		// 8-adjacency
//		drawPixelConnectToEdge(col - 1, row - 1, canny_edge, target_edge, has_drawed);
//		drawPixelConnectToEdge(col, row - 1, canny_edge, target_edge, has_drawed);
//		drawPixelConnectToEdge(col + 1, row - 1, canny_edge, target_edge, has_drawed);
//		drawPixelConnectToEdge(col - 1, row, canny_edge, target_edge, has_drawed);
//		drawPixelConnectToEdge(col + 1, row, canny_edge, target_edge, has_drawed);
//		drawPixelConnectToEdge(col - 1, row + 1, canny_edge, target_edge, has_drawed);
//		drawPixelConnectToEdge(col, row + 1, canny_edge, target_edge, has_drawed);
//		drawPixelConnectToEdge(col + 1, row + 1, canny_edge, target_edge, has_drawed);
//	}
//}
//
//CImg<unsigned char> getRectangleEdgeFromCanny(const CImg<unsigned char>& canny_edge) {
//	int src_width = canny_edge.width();
//	int src_height = canny_edge.height();
//
//	CImg<bool> has_visited(src_width, src_height, 1, 1, 0);
//
//	int max_connectivity_count = 0;
//	int col_pos = 0;
//	int row_pos = 0;
//
//	for (int col = 0; col < src_width; col++) {
//		for (int row = 0; row < src_height; row++) {
//			if (canny_edge(col, row) != 0) {
//				int connectivity_count = getNumOfEdgePixelConnectToEdge(col, row, canny_edge, has_visited);
//
//				if (connectivity_count > max_connectivity_count) {
//					max_connectivity_count = connectivity_count;
//					col_pos = col;
//					row_pos = row;
//				}
//			}
//		}
//	}
//
//	CImg<unsigned char> res(src_width, src_height, 1, 1, 0);
//	CImg<bool> has_drawed(src_width, src_height, 1, 1, 0);
//
//	drawPixelConnectToEdge(col_pos, row_pos, canny_edge, res, has_drawed);
//
//	return res;
//}