#ifndef _CANNY_H_
#define _CANNY_H_

#include "Gaussian.h"

#define WINDOW_SIZE 33
#define HYSTERESIS_THRESHOLD_LOW 40
#define HYSTERESIS_THRESHOLD_HIGH 85

CImg<float> getOneDimensionalGradient(const CImg<float>& src_img, bool isX);
CImg<float> getGradient(const CImg<float>& dx, const CImg<float>& dy);
CImg<unsigned char> getAngelOfGradient(const CImg<float>& dx, const CImg<float>& dy);
CImg<float> nonMaximumSuppression(const CImg<float>& gradient, const CImg<unsigned char>& theta);
CImg<unsigned char> hysteresisThresholding(const CImg<float>& suppression, int threshold_low, int threshold_high);

CImg<unsigned char> cannyEdgeDection(const CImg<float>& src_img);

/* Have problems */
// CImg<unsigned char> getRectangleEdgeFromCanny(const CImg<unsigned char>& canny_edge);

#endif